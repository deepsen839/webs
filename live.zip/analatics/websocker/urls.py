"""
URL configuration for websocker project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from active_inactive.views import *
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', index, name='index'),
    # path('update-status/', update_status, name='update_status'),
    path('check-status/', check_status, name='check_status'),
    path('click-points/', click_points, name='click-points'),
    path('hover-points/',hover_points,name='hover-points'),
    path('enter-location-details/',enter_location_details,name='enter-location-details'),
    path('upload-image/',handle_uploaded_file,name='save-records'),
    path('save-records/',save_record,name='upload-image'),
    path('get-records/<str:id>/',get_record,name='get-records'),
    path('create-campaign/',create_campaign,name='create-campaign'),
    path('get-campaign-details/<int:id>/',get_campaign_details,name='get-campaign-details'),
    path('list-campaign/',list_campaign,name='list-campaign'),
    path('generate-code/<int:id>/',generate_code,name='generate-code'),
    path('view-visitor-details/',get_all_records,name='view-visitor-details'),
    path('play-specific-record/<int:id>/',play_specific_record,name='play-specific-record'),
    path('play-live-record/',play_live_records,name='play-live-record'),
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
