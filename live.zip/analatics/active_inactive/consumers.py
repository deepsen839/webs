import json
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import Status
import sys
class StatusConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        print('22222222222222')
        await self.channel_layer.group_add("my_group", self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard("my_group", self.channel_name)

    async def receive(self, text_data):
        print("Receive method called")
        print(f"text_data: {text_data}")
        print('222222222222')
        #data = json.loads(text_data)
        # print(data)

        # is_active = data['is_active']
        await self.channel_layer.group_send(
            "my_group",
            {
                'type': 'status_message',
                'events':text_data,
                # 'message':data['message'],
                # 'is_active': is_active
            }
        )

    async def status_message(self, event):

        # is_active = event['is_active']
        await self.send(text_data=event['events'])
