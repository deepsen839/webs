from django.shortcuts import render,redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
# from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
import json
from .models import *
from django.conf import settings
import base64
# import imgkit
from .models import *
# from html2image import Html2Image
import uuid
# from jsmin import jsmin
import requests
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Count
import base64


def index(request):
    className = 'dashboard'
    device_wise_records = SaveRecords.objects.values('device').annotate(total_user=Count('user_ip',distinct=True))
    os_wise_records = SaveRecords.objects.values('os').annotate(total_user=Count('user_ip',distinct=True))
    country_user_ip_counts = SaveRecords.objects.values('country').annotate(total_user=Count('user_ip',distinct=True))
    total_user =  SaveRecords.objects.values('user_ip').distinct().count()
    context = {
                'className':className,
               'device_wise_records':device_wise_records,
               'os_wise_records':os_wise_records,
               'country_wise_users':country_user_ip_counts,
               'total_user':total_user,
               'device':'',
               'os':'',
               'country':''
               }
    
    if  request.method=='POST':
        device = request.POST.get('device','')
        operating_system = request.POST.get('operating_system','')
        country = request.POST.get('country','')
        filter_criteria = {}
        if device:
            filter_criteria['device'] = device
        if operating_system:
            filter_criteria['os'] = operating_system
        if country:
            filter_criteria['country'] = country
          
        device_wise_records = SaveRecords.objects.filter(**filter_criteria).values('device').annotate(total_user=Count('user_ip',distinct=True))
        os_wise_records = SaveRecords.objects.filter(**filter_criteria).values('os').annotate(total_user=Count('user_ip',distinct=True))
        country_user_ip_counts = SaveRecords.objects.filter(**filter_criteria).values('country').annotate(total_user=Count('user_ip',distinct=True))
        total_user =  SaveRecords.objects.filter(**filter_criteria).values('user_ip').distinct().count()
        context = {
                'className':className,
               'device_wise_records':device_wise_records,
               'os_wise_records':os_wise_records,
               'country_wise_users':country_user_ip_counts,
               'total_user':total_user,
               'device':device,
               'os':operating_system,
               'country':country
               }
        
    return render(request,'dashboard.html',context)

def create_campaign(request):
    try:
        if request.method=='POST':
            campaign = request.POST.get('campaign')
            website_name_link = request.POST.get('website_name')
            create_campaign = CreateCampaign.objects.create(campaign_name=campaign,website_name=website_name_link)
            if create_campaign:
                return redirect('list-campaign')
    except Exception as e:
        print(e)    
    
       
    return render(request,'create_campaign.html')
    
def list_campaign(request):
    campaign_records = CreateCampaign.objects.all()
    print(vars(campaign_records))
    return render(request,'list_campaign.html',{'campaign_records':campaign_records})

def generate_code(request,id):
    campaign_unique_id=''
    uid = ''
    try:
        campaign_records = CampaignUniqueID.objects.get(campaign_id=id)
        uid = campaign_records.unique_id
    except ObjectDoesNotExist:
        uid = uuid.uuid4()
        campaign_records = CampaignUniqueID.objects.create(campaign_id=id,unique_id=uid)

    if campaign_records:
        script = f"""
        document.addEventListener('DOMContentLoaded',function(e){{
            let uuid = '{uid}';
            const link = document.createElement("link");
            link.href = "https://cdn.jsdelivr.net/npm/rrweb-player@latest/dist/style.css";
            link.rel = "stylesheet";
            document.head.appendChild(link);
            let script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/rrweb@latest/dist/rrweb-all.js'
            document.head.appendChild(script);
            let script1 = document.createElement('script');
            script1.src = '{settings.BASE_URL}/static/main.js';
            document.head.appendChild(script1);
        }})
    """
        minified = ''
        with open('script.js','w') as f:
            f.write(script)
        javascript_file = minify_js('script.js',False)
        javascript_file = f"""<script>let uuid = '{uid}';{javascript_file}</script>"""
        encoded_file = base64.b32encode(javascript_file)
        print(encoded_file)
        return render(request,'generate_code.html',{'minified_script':javascript_file})
        
        

def view_visitor_details(request,unique_id):
    pass
    
    return render(request)



# @csrf_exempt
# def update_status(request):
#     hti = Html2Image(custom_flags=['--virtual-time-budget=10000', '--hide-scrollbars'])
#     hti.screenshot(url='http://localhost/hello/',save_as='python_org.png')
#     if request.method == 'POST':
#         status = Status.objects.first()
#         if status:
#             status.is_active = not status.is_active
#             status.save()
#             # Notify WebSocket clients
#             channel_layer = get_channel_layer()
#             async_to_sync(channel_layer.group_send)(
#                 "my_group",
#                 {
#                     'type': 'status_message',
#                     'hello':'11111111',
#                     'is_active': status.is_active
#                 }
#             )
            
            
#             return JsonResponse({'status': 'success'})
#     return JsonResponse({'status': 'failed'})

def check_status(request):
    return render(request,'check_status.html')

def click_points(request):
    try:
        if request.method=='POST':
            data = json.loads(request.body)
            for points in data['click_points']:
                # print(points)
                ClickPoints.objects.create(xcordinate=points['x'],ycordinate=points['y'])
            return JsonResponse({'msg':'success'})     
    except Exception as e:
        print(e)
        return JsonResponse({'msg':'failure'})        

def hover_points(request):
    try:
        if request.method=='POST':
            data = json.loads(request.body)
            for points in data['hover_points']:
                # print(points)
                HoverPoints.objects.create(xcordinate=points['x'],ycordinate=points['y'])
            return JsonResponse({'msg':'success'})    
    except Exception as e:
        print(e)
        return JsonResponse({'msg':'failure'})

def enter_location_details(request):
    if request.method=='POST':
        try:
            data = json.loads(request.body)
            received_record = data['data']
            city = received_record['city']
            ip = received_record['ip']
            loc = received_record['loc']
            orgnization = received_record['org']
            postal = received_record['postal']
            regions =  received_record['region']
            timezone = received_record['timezone']
            user_location_exists = UserLocation.objects.filter(ip=ip).exists()
            if user_location_exists:
                user_location = UserLocation.objects.get(ip=ip)
                return JsonResponse({'msg':'success','user_id':user_location.id})
            else:
                user_location = UserLocation.objects.create(city=city,ip=ip,loc=loc,orgnization=orgnization,postal=postal,regions=regions,timezone=timezone)
                user_location.save()
                return JsonResponse({'msg':'success','user_id':user_location.id})
        except Exception as e:
            print(e)
            return JsonResponse({'msg':'error'})
        
@csrf_exempt
def handle_uploaded_file(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            image_data = base64.b64decode(data['image'])

            image_path = f"{settings.MEDIA_ROOT}/heatmap.jpeg"
            text_path = f"{settings.MEDIA_ROOT}/heatmap.txt"

            # Write the image data to a .jpeg file
            with open(image_path, "wb") as image_destination:
                image_destination.write(image_data)

            # Write the image data to a .txt file (as base64 string)
            with open(text_path, "w") as text_destination:
                text_destination.write(image_data)

            return JsonResponse({'message': 'File uploaded successfully'}, status=200)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=400)

@csrf_exempt
def save_record(request):
    if request.method=='POST':
        try:
            data = json.loads(request.body.decode("utf-8"))
            os = data['operating_system']
            city = data['city']
            region = data['region']
            country = data['country']
            timezone = data['timezone']
            device = 'desktop'
            if data['mobile']:
                device = 'mobile'
            elif data['tablet']:
                device = 'tablet'
            operating_system = 'Linux'    
            if 'Windows' in os:
                operating_system = 'windows'
            elif 'Mac OS' in os or 'iOS' in os or 'Mac OS X' in os:
                operating_system = 'Mac'

                 
            save_record = SaveRecords.objects.create(events=json.dumps(data['events']),
                                       unique_records = data['uid'],
                                       url_location = data['url'],
                                       user_ip = data['ipaddress'],
                                       city = city,
                                       region = region,
                                       country = country,
                                       timezone = timezone,
                                       device=device,
                                       os = operating_system
                                       )
            if save_record:
                return JsonResponse({'msg':'success'})
        except Exception as e:
            print(e)
            return JsonResponse({'msg':'failure'}) 
        
@csrf_exempt
def get_record(request,id):
    get_records = SaveRecords.objects.filter(unique_records=id).all()
    return render(request,'get_records_list.html',{'get_records':get_records})



def minify_js(js_file, overwrite=False):
    js = ''
    with open(js_file, 'r') as f:
        js = f.read()
    print(js)    
    req = requests.post('https://javascript-minifier.com/raw', {'input': js})
    save_path = js_file
    # print(vars(req))
    if not overwrite:
        save_path = js_file[:-3] + '.min.js'
    with open(save_path, 'w') as f:
        f.write(req.text)
    # return save_path
    return req.text

def get_all_records(request):
    saved_records = CampaignUniqueID.objects.all()
    return render(request,'play_records_list.html',{'saved_records':saved_records})


@csrf_exempt
def play_specific_record(request,id):
    if request.method=='POST':
        data = json.loads(request.body.decode('utf-8'))
        records = SaveRecords.objects.get(pk=data['id'])
        return JsonResponse({'events':records.events})
    return render(request,'play_status.html',{'id':id})

def get_campaign_details(request,id):
    get_saved_records = ''
    try:
        campaign_unique_records = CampaignUniqueID.objects.get(pk=id)
        get_saved_records = SaveRecords.objects.filter(unique_records=campaign_unique_records.unique_id).all()
    except Exception as e:
        print(e)
    return render(request,'get_campaign_details.html',{'get_saved_records':get_saved_records})

@csrf_exempt
def play_live_records(request):
    return render(request,'play_live_details.html')
    
  
               
            
            
        
        
           
