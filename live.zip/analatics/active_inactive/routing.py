from channels.routing import ProtocolTypeRouter, URLRouter
from django.urls import path
from active_inactive.consumers import StatusConsumer
from django.urls import re_path

# import active_inactive.routing
# application = ProtocolTypeRouter({
#     'websocket': URLRouter([
#         re_path(r'ws/status/$', StatusConsumer.as_asgi()),
#     ])
# })
websocket_urlpatterns = [
   re_path(r'ws/status/$', StatusConsumer.as_asgi())
]