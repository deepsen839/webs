
// document.addEventListener("DOMContentLoaded", function () {
//   checkUserDetails();

//   let deviceosdetails = {
//     operating_system: jscd.os,
//     browser: jscd.browser,
//     mobile: jscd.mobile,
//     tablet: jscd.tablet,
//     desktop: jscd.desktop,
//     screen_size: jscd.screen,
//   };
// console.log(deviceosdetails)
//   let events = [];
//   rrweb.record({
//     emit(event) {
//       // push event into the events array

//       events.push(event);
//       console.log(events);
//       //   console.log(JSON.stringify( {events} ))
//     },
//     // checkoutEveryNms:10
//   });
//   window.onbeforeunload = function (events2) {
//     deviceosdetails["events"] = { events };

//     events2.preventDefault();
//     fetch("http://192.168.10.133:8000/save-records/", {
//       method: "POST",
//       body: JSON.stringify(deviceosdetails),
//     })
//       .then((data) => data.json())
//       .then((data) => {
//         console.log(data);
//       })
//       .catch((error) => {
//         console.log("error occured", error);
//       });
//   };
// });


window.onload =function(event){
  const chatSocket = new WebSocket('ws://192.168.10.207:8000/ws/status/');

  chatSocket.onopen = function(event) {
    console.log('WebSocket connection established.');
   
    rrweb.record({
      emit(event) {
        // push event into the recordedEvents array
        // recordedEvents.push(event);
        chatSocket.send(JSON.stringify({event}));
      },
      // checkoutEveryNms:10
    });


    
  };


  // rrweb.record({
  //   emit(event) {
  //     // push event into the recordedEvents array
  //     recordedEvents.push(event);
  //     console.log(recordedEvents);
  //   },
  //   // checkoutEveryNms:10
  // });
} 




