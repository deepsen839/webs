window.onload = function (event) {
  const chatSocket = new WebSocket("ws://localhost:8000/ws/status/");

  chatSocket.onopen = function (event) {
    console.log("WebSocket connection established.");

    rrweb.record({
      emit(event) {
        // push event into the recordedEvents array
        // recordedEvents.push(event);
        chatSocket.send(JSON.stringify(event));
      },
      // checkoutEveryNms:10
    });
  };
};
