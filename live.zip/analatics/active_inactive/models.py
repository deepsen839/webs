# Create your models here.
from django.db import models
from uuid import UUID
class Status(models.Model):
    is_active = models.BooleanField(default=False)

class UserLocation(models.Model):
    city = models.CharField(max_length=255,null=True)
    ip = models.CharField(max_length=255,null=True)
    loc = models.CharField(max_length=255,null=True)
    orgnization = models.CharField(max_length=255,null=True)
    postal = models.CharField(max_length=255,null=True)
    regions = models.CharField(max_length=255,null=True)
    timezone = models.CharField(max_length=255,null=True) 
    class Meta:
        db_table = 'user_location'
            
class ClickPoints(models.Model):
    xcordinate = models.CharField(max_length=255,null=True)
    ycordinate = models.CharField(max_length=255,null=True)
    class Meta:
        db_table = 'click_points'    

class HoverPoints(models.Model):
    xcordinate = models.CharField(max_length=255,null=True)
    ycordinate = models.CharField(max_length=255,null=True)
    class Meta:
        db_table = 'hover_points'
        
        
class SaveRecords(models.Model):
    unique_records = models.CharField(max_length=255,null=True) 
    url_location=models.CharField(max_length=255,null=True)
    user_ip = models.CharField(max_length=255,null=True)
    url = models.CharField(max_length=255,null=True)
    city = models.CharField(max_length=255,null=True)
    region = models.CharField(max_length=255,null=True)
    country = models.CharField(max_length=255,null=True)
    timezone = models.CharField(max_length=255,null=True)
    device = models.CharField(max_length=255,null=True)
    os = models.CharField(max_length=255,null=True)
    events = models.TextField(null=True)
    class Meta:
        db_table = 'save_records'  
        
        
class CreateCampaign(models.Model):
    campaign_name = models.CharField(max_length=255,null=True)
    website_name = models.CharField(max_length=255,null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        db_table = 'campaign_name'

class CampaignUniqueID(models.Model):
    campaign = models.ForeignKey(CreateCampaign,on_delete=models.DO_NOTHING)
    unique_id = models.UUIDField()
    class Meta:
        db_table = 'campaign_unique_id'                     